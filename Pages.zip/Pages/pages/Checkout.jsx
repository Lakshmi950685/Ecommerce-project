import { useCart } from "../context/CartContext";
import { useNavigate } from "react-router-dom";
import { FaTrash } from "react-icons/fa";

function Checkout() {
  const {
    cart,
    removeItem,
    totalPrice,
  } = useCart();

  const navigate = useNavigate();

  const placeOrder = () => {
    alert("🎉 Order Placed Successfully!");
    navigate("/");
  };

  return (
    <div className="checkout-page">

      <div className="checkout-header">
        <h1>Checkout</h1>

        <button
          className="back-btn"
          onClick={() => navigate("/")}
        >
          ← Continue Shopping
        </button>
      </div>

      {
        cart.length === 0 ? (
          <div className="empty-checkout">
            <h2>Your Cart is Empty</h2>

            <button
              className="shop-btn"
              onClick={() => navigate("/")}
            >
              Shop Now
            </button>
          </div>
        ) : (
          <>
            <div className="checkout-items">

              {cart.map((item) => (

                <div
                  className="checkout-card"
                  key={item.id}
                >

                  <img
                    src={item.image}
                    alt={item.title}
                  />

                  <div className="checkout-info">

                    <h3>{item.title}</h3>

                    <p>Category : {item.category}</p>

                    <p>Price : ${item.price}</p>

                    <p>Quantity : {item.quantity}</p>

                    <h4>
                      Total : $
                      {(item.price * item.quantity).toFixed(2)}
                    </h4>

                  </div>

                  <button
                    className="remove-btn"
                    onClick={() => removeItem(item.id)}
                  >
                    <FaTrash />
                  </button>

                </div>

              ))}

            </div>

            <div className="summary-box">

              <h2>
                Grand Total : $
                {totalPrice.toFixed(2)}
              </h2>

              <button
                className="place-btn"
                onClick={placeOrder}
              >
                Place Order
              </button>

            </div>
          </>
        )
      }

    </div>
  );
}

export default Checkout;