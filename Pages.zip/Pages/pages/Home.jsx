import { useState } from "react";
import { useCart } from "../context/CartContext";

import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";
import Banner from "../components/Banner";
import ProductGrid from "../components/ProductGrid";
import CartPopup from "../components/CartPopup";

function Home() {
  const [isCartOpen, setIsCartOpen] = useState(false);

  const { cart } = useCart();

  const cartCount = cart.reduce(
    (total, item) => total + item.quantity,
    0
  );

  return (
    <>
      <Navbar
        toggleCart={() => setIsCartOpen(true)}
        cartCount={cartCount}
      />

      <div className="home-layout">

        <Sidebar />

        <main className="main">

          <Banner />

          <ProductGrid />

        </main>

      </div>

      <CartPopup
        isOpen={isCartOpen}
        closeCart={() => setIsCartOpen(false)}
      />
    </>
  );
}

export default Home;