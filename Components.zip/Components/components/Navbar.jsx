import { FaShoppingCart } from "react-icons/fa";

function Navbar({ toggleCart, cartCount }) {
  return (
    <nav className="navbar">
      <div className="logo">
        PickBazar
      </div>

      <div className="nav-links">
        <a href="#">Shops</a>
        <a href="#">Offers</a>
        <a href="#">Contact</a>
        <a href="#">Pages</a>
      </div>

      <button className="cart-btn" onClick={toggleCart}>
        <FaShoppingCart /> ({cartCount})
      </button>
    </nav>
  );
}

export default Navbar;