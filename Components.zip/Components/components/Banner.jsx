function Banner() {
  return (
    <div className="banner-section">

      <div className="banner-card">
        <img
          src="https://images.unsplash.com/photo-1542838132-92c53300491e?w=1200"
          alt="Fresh Vegetables"
        />
        <div className="banner-text">
          <h2>Fresh Vegetables</h2>
          <p>Get up to 30% OFF</p>
          <button>Shop Now</button>
        </div>
      </div>

      <div className="banner-grid">

        <div className="small-banner">
          <img
            src="https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=800"
            alt="Healthy Fruits"
          />
          <div className="small-text">
            <h3>Healthy Fruits</h3>
            <p>Fresh Every Day</p>
          </div>
        </div>

        <div className="small-banner">
          <img
            src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800"
            alt="Organic Foods"
          />
          <div className="small-text">
            <h3>Organic Foods</h3>
            <p>100% Natural</p>
          </div>
        </div>

      </div>

    </div>
  );
}

export default Banner;