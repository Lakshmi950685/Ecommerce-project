import { useCart } from "../context/CartContext";
import { FaShoppingCart } from "react-icons/fa";

function ProductCard({ product }) {
  const { addToCart } = useCart();

  return (
    <div className="product-card">
      <div className="product-image">
        <img src={product.image} alt={product.title} />
      </div>

      <div className="product-info">
        <h3>{product.title}</h3>

        <p className="product-category">
          {product.category}
        </p>

        <div className="price-cart">
          <span className="price">
            ${product.price}
          </span>

          <button
            className="add-cart-btn"
            onClick={() => addToCart(product)}
          >
            <FaShoppingCart />
            Add
          </button>
        </div>
      </div>
    </div>
  );
}

export default ProductCard;