import { useCart } from "../context/CartContext";
import { useNavigate } from "react-router-dom";
import {
  FaPlus,
  FaMinus,
  FaTrash,
  FaTimes,
} from "react-icons/fa";

function CartPopup({ isOpen, closeCart }) {
  const {
    cart,
    increaseQty,
    decreaseQty,
    removeItem,
    totalPrice,
  } = useCart();

  const navigate = useNavigate();

  if (!isOpen) return null;

  return (
    <>
      <div className="overlay" onClick={closeCart}></div>

      <div className="cart-popup">

        <div className="cart-header">
          <h2>Shopping Cart</h2>

          <button
            className="close-btn"
            onClick={closeCart}
          >
            <FaTimes />
          </button>
        </div>

        {
          cart.length === 0 ? (
            <div className="empty-cart">
              <h3>Your Cart is Empty</h3>
            </div>
          ) : (
            <>
              <div className="cart-items">

                {cart.map((item) => (
                  <div
                    className="cart-item"
                    key={item.id}
                  >
                    <img
                      src={item.image}
                      alt={item.title}
                    />

                    <div className="cart-info">
                      <h4>{item.title}</h4>

                      <p>
                        $
                        {(item.price * item.quantity).toFixed(
                          2
                        )}
                      </p>

                      <div className="qty-box">

                        <button
                          onClick={() =>
                            decreaseQty(item.id)
                          }
                        >
                          <FaMinus />
                        </button>

                        <span>
                          {item.quantity}
                        </span>

                        <button
                          onClick={() =>
                            increaseQty(item.id)
                          }
                        >
                          <FaPlus />
                        </button>

                      </div>
                    </div>

                    <button
                      className="delete-btn"
                      onClick={() =>
                        removeItem(item.id)
                      }
                    >
                      <FaTrash />
                    </button>

                  </div>
                ))}

              </div>

              <div className="cart-footer">

                <h3>
                  Total : $
                  {totalPrice.toFixed(2)}
                </h3>

                <button
                  className="checkout-btn"
                  onClick={() => {
                    closeCart();
                    navigate("/checkout");
                  }}
                >
                  Checkout
                </button>

              </div>
            </>
          )
        }

      </div>
    </>
  );
}

export default CartPopup;