import {
  FaAppleAlt,
  FaFish,
  FaBreadSlice,
  FaCarrot,
  FaIceCream,
  FaCheese,
  FaCoffee,
  FaHamburger,
  FaGift,
  FaLeaf
} from "react-icons/fa";

function Sidebar() {
  const categories = [
    { icon: <FaAppleAlt />, name: "Fruits & Vegetables" },
    { icon: <FaFish />, name: "Meat & Fish" },
    { icon: <FaBreadSlice />, name: "Snacks" },
    { icon: <FaCarrot />, name: "Vegetables" },
    { icon: <FaIceCream />, name: "Dairy" },
    { icon: <FaCheese />, name: "Cheese" },
    { icon: <FaCoffee />, name: "Beverages" },
    { icon: <FaHamburger />, name: "Fast Food" },
    { icon: <FaGift />, name: "Gift Items" },
    { icon: <FaLeaf />, name: "Organic Foods" }
  ];

  return (
    <aside className="sidebar">
      <h3>Categories</h3>

      <ul>
        {categories.map((item, index) => (
          <li key={index}>
            <span
              style={{
                marginRight: "10px",
                color: "#00b894"
              }}
            >
              {item.icon}
            </span>

            {item.name}
          </li>
        ))}
      </ul>
    </aside>
  );
}

export default Sidebar;